//alert("testing");
$(document).ready(function() {
  /*  $("body").backgroundCycle({
        imageUrls: [
            '/resources/images/Bg1.jpg',
            '/resources/images/Bg2.jpg',
            '/resources/images/Bg3.jpg'
        ],
        fadeSpeed: 2000,
        duration: 5000,
        backgroundSize: SCALING_MODE_COVER
    });*/
	
	function cssChange(element){
		element.toggleClass("btn btn-success");
	}
	
	
});