package com.justask.spring.pojo;

public class ReviewVenueCount {
	
	private Long count;
	
	private int venueId;

	public ReviewVenueCount(){
		
	}
	
	

	public Long getCount() {
		return count;
	}



	public void setCount(Long count) {
		this.count = count;
	}



	public int getVenueId() {
		return venueId;
	}

	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}
	
	

}
